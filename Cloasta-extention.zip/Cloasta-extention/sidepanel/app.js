/**
 * Cloasta — Main Application Controller
 * 
 * Handles tab switching, theme toggle, event binding,
 * and orchestrates the optimizer/summarizer workflows.
 */

import { optimizePrompt } from '../engine/promptOptimizer.js';
import { summarizeConversation } from '../engine/conversationSummarizer.js';
import { adaptPrompt, getModelProfiles } from '../engine/modelAdapter.js';
import { getAvailableModes } from '../engine/templates.js';
import { initPassportUI } from './passportUI.js';
import { enhancePrompt } from '../engine/openrouterClient.js';
import { initBillingUI, attemptAction } from './billingUI.js';

/* ══════════════════════════════════════════════
   STATE
   ══════════════════════════════════════════════ */

const state = {
  currentTab: 'optimize',
  selectedMode: 'founder',
  selectedModel: 'generic',
  summarizeModel: 'generic',
  settings: {
    includePassport: true,
    autoMode: true,
    showMemory: true,
    showSuggested: true,
    apiProvider: 'none',
    apiKey: ''
  },
  lastOptimizeResult: null,
  lastSummarizeResult: null
};


/* ══════════════════════════════════════════════
   INITIALIZATION
   ══════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  initTheme();
  initTabs();
  initModeSelector();
  initModelChips();
  initOptimizer();
  initSummarizer();
  initSettingsPanel();
  initPassportUI();
  initTextStats();
  initExportImport();
  initOnboarding();
  initBillingUI();

  // Listen for messages from background and content scripts
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'CLOASTA_CONVERSATION_DATA') {
        const inputEl = document.getElementById('summarize-input');
        if (inputEl) {
          inputEl.value = message.text || '';
          inputEl.dispatchEvent(new Event('input'));
        }
        const tabBtn = document.querySelector('.tab-btn[data-tab="summarize"]');
        if (tabBtn) tabBtn.click();
        showToast('Conversation loaded');
        if (sendResponse) sendResponse({ status: 'ok' });
      } else if (message.type === 'CLOASTA_CONTEXT_MENU') {
        const inputEl = document.getElementById('optimize-input');
        if (inputEl) {
          inputEl.value = message.text || '';
          inputEl.dispatchEvent(new Event('input'));
        }
        const tabBtn = document.querySelector('.tab-btn[data-tab="optimize"]');
        if (tabBtn) tabBtn.click();
        showToast('Text loaded');
        if (sendResponse) sendResponse({ status: 'ok' });
      }
    });
  }
});


/* ══════════════════════════════════════════════
   THEME
   ══════════════════════════════════════════════ */

function initTheme() {
  const toggle = document.getElementById('theme-toggle');
  const html = document.documentElement;

  // Load saved theme
  loadFromStorage('cloasta_theme', (theme) => {
    if (theme) {
      html.setAttribute('data-theme', theme);
      updateThemeIcon(theme);
    }
  });

  toggle.addEventListener('click', () => {
    const current = html.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    updateThemeIcon(next);
    saveToStorage('cloasta_theme', next);
  });
}

function updateThemeIcon(theme) {
  const sunIcon = document.querySelector('.icon-sun');
  const moonIcon = document.querySelector('.icon-moon');
  if (theme === 'dark') {
    sunIcon.classList.remove('hidden');
    moonIcon.classList.add('hidden');
  } else {
    sunIcon.classList.add('hidden');
    moonIcon.classList.remove('hidden');
  }
}


/* ══════════════════════════════════════════════
   TABS
   ══════════════════════════════════════════════ */

function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.tab-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.dataset.tab;
      state.currentTab = targetTab;

      // Update buttons
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // Update panels
      panels.forEach(p => p.classList.remove('active'));
      const targetPanel = document.getElementById(`panel-${targetTab}`);
      if (targetPanel) {
        targetPanel.classList.add('active');
      }
    });
  });
}


/* ══════════════════════════════════════════════
   MODE SELECTOR
   ══════════════════════════════════════════════ */

function initModeSelector() {
  const modeBtns = document.querySelectorAll('.mode-btn');

  modeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedMode = btn.dataset.mode;
      modeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}


/* ══════════════════════════════════════════════
   MODEL CHIPS
   ══════════════════════════════════════════════ */

function initModelChips() {
  // Optimize tab chips
  const optimizeChips = document.querySelectorAll('#model-chips .model-chip');
  optimizeChips.forEach(chip => {
    chip.addEventListener('click', () => {
      state.selectedModel = chip.dataset.model;
      optimizeChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      // Re-adapt if we have results
      if (state.lastOptimizeResult) {
        reAdaptOptimizedPrompt();
      }
    });
  });

  // Summarize tab chips
  const summarizeChips = document.querySelectorAll('#summarize-model-chips .model-chip');
  summarizeChips.forEach(chip => {
    chip.addEventListener('click', () => {
      state.summarizeModel = chip.dataset.model;
      summarizeChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      // Re-adapt if we have results
      if (state.lastSummarizeResult) {
        reAdaptSummarizedPrompt();
      }
    });
  });
}


/* ══════════════════════════════════════════════
   OPTIMIZER
   ══════════════════════════════════════════════ */

function initOptimizer() {
  const btn = document.getElementById('optimize-btn');
  const input = document.getElementById('optimize-input');
  const outputContainer = document.getElementById('optimize-output-container');
  const copyBtn = document.getElementById('copy-optimized-btn');
  const copySuggestedBtn = document.getElementById('copy-suggested-btn');

  btn.addEventListener('click', async () => {
    const rawInput = input.value.trim();
    if (!rawInput) {
      showToast('Please enter some text to optimize');
      return;
    }

    const allowed = await attemptAction('optimize');
    if (!allowed) {
      showToast('Limit Reached', 3000);
      return;
    }

    // Show loading state
    btn.disabled = true;
    btn.innerHTML = `
      <div class="loading-spinner" style="width:16px;height:16px;border-width:2px;"></div>
      Optimizing...
    `;

    try {
      // Run optimizer (Rule-based)
      let result = await optimizePrompt(rawInput, {
        mode: state.settings.autoMode ? null : state.selectedMode,
        includePassport: state.settings.includePassport,
        targetModel: state.selectedModel
      });

      // If auto-mode detected a different mode, update the UI
      if (state.settings.autoMode && result.metadata.detectedMode !== state.selectedMode) {
        state.selectedMode = result.metadata.detectedMode;
        document.querySelectorAll('.mode-btn').forEach(b => {
          b.classList.toggle('active', b.dataset.mode === state.selectedMode);
        });
      }

      // If OpenRouter is selected and API key exists, enhance the prompt
      if (state.settings.apiProvider === 'openrouter' && state.settings.apiKey) {
        btn.innerHTML = `
          <div class="loading-spinner" style="width:16px;height:16px;border-width:2px;"></div>
          Optimizing with AI...
        `;
        
        try {
          const aiResult = await enhancePrompt(result.optimizedPrompt, state.settings.apiKey);
          // Merge AI results back into the main result object
          result.optimizedPrompt = aiResult.optimizedPrompt;
          if (aiResult.summary) result.contextSummary = aiResult.summary;
          if (aiResult.memoryPoints && aiResult.memoryPoints.length > 0) result.memoryPoints = aiResult.memoryPoints;
          if (aiResult.suggestedFollowUp) result.suggestedNext = aiResult.suggestedFollowUp;
        } catch (aiError) {
          console.warn('AI enhancement failed, falling back to rule-based:', aiError);
          showToast('AI optimization failed. Using fast rule-based fallback.', 4000);
        }
      }

      state.lastOptimizeResult = result;

      // Adapt for selected model
      const adapted = adaptPrompt(result.optimizedPrompt, state.selectedModel);

      // Display results
      displayOptimizeResults(adapted, result);

      outputContainer.style.display = 'block';
      outputContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });

    } catch (error) {
      console.error('Optimization error:', error);
      showToast('Error optimizing prompt. Please try again.');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
          <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
        </svg>
        Optimize Prompt
      `;
    }
  });

  // Copy buttons
  copyBtn.addEventListener('click', () => {
    const output = document.getElementById('optimized-output');
    copyToClipboard(output.textContent);
  });

  copySuggestedBtn.addEventListener('click', () => {
    const output = document.getElementById('suggested-next-output');
    copyToClipboard(output.textContent);
  });
}

function displayOptimizeResults(adaptedPrompt, result) {
  // Main output
  const outputEl = document.getElementById('optimized-output');
  outputEl.textContent = adaptedPrompt;
  outputEl.classList.remove('empty');

  // Model & Timestamp details
  const modelUsedEl = document.getElementById('output-model-used');
  const timestampEl = document.getElementById('output-timestamp');
  if (modelUsedEl && timestampEl) {
    const isEnhanced = !!result.contextSummary; // OpenRouter was used
    modelUsedEl.textContent = isEnhanced ? `${state.selectedModel} (AI Enhanced)` : state.selectedModel;
    
    const now = new Date();
    timestampEl.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // Stats
  document.getElementById('output-word-count').textContent = countWords(adaptedPrompt);
  document.getElementById('output-char-count').textContent = adaptedPrompt.length;
  const ratio = result.metadata.compressionRatio;
  document.getElementById('compression-ratio').textContent = ratio >= 0 ? ratio : 0;

  // Context Summary
  const summaryEl = document.getElementById('context-summary-output');
  summaryEl.textContent = result.contextSummary || 'No additional context extracted.';

  // Memory Points
  const memoryCard = document.getElementById('memory-points-card');
  const memoryEl = document.getElementById('memory-points-output');
  if (state.settings.showMemory && result.memoryPoints.length > 0) {
    memoryCard.style.display = 'block';
    memoryEl.textContent = result.memoryPoints.map(p => `• ${p}`).join('\n');
  } else {
    memoryCard.style.display = 'none';
  }

  // Suggested Next
  const suggestedCard = document.getElementById('suggested-next-card');
  const suggestedEl = document.getElementById('suggested-next-output');
  if (state.settings.showSuggested && result.suggestedNext) {
    suggestedCard.style.display = 'block';
    suggestedEl.textContent = result.suggestedNext;
  } else {
    suggestedCard.style.display = 'none';
  }
}

function reAdaptOptimizedPrompt() {
  if (!state.lastOptimizeResult) return;
  const adapted = adaptPrompt(state.lastOptimizeResult.optimizedPrompt, state.selectedModel);
  const outputEl = document.getElementById('optimized-output');
  outputEl.textContent = adapted;
  document.getElementById('output-word-count').textContent = countWords(adapted);
  document.getElementById('output-char-count').textContent = adapted.length;
}


/* ══════════════════════════════════════════════
   SUMMARIZER
   ══════════════════════════════════════════════ */

function initSummarizer() {
  const btn = document.getElementById('summarize-btn');
  const input = document.getElementById('summarize-input');
  const outputContainer = document.getElementById('summarize-output-container');
  const copyBtn = document.getElementById('copy-summary-btn');

  btn.addEventListener('click', async () => {
    const rawInput = input.value.trim();
    if (!rawInput) {
      showToast('Please paste a conversation to summarize');
      return;
    }

    const allowed = await attemptAction('summarize');
    if (!allowed) {
      showToast('Limit Reached', 3000);
      return;
    }

    // Show loading state
    btn.disabled = true;
    btn.innerHTML = `
      <div class="loading-spinner" style="width:16px;height:16px;border-width:2px;"></div>
      Summarizing...
    `;

    try {
      const result = summarizeConversation(rawInput);
      state.lastSummarizeResult = result;

      // Adapt for selected model
      const adapted = adaptPrompt(result.continuationPrompt, state.summarizeModel);

      // Display results
      displaySummarizeResults(adapted, result);

      outputContainer.style.display = 'block';
      outputContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });

    } catch (error) {
      console.error('Summarization error:', error);
      showToast('Error summarizing conversation. Please try again.');
    } finally {
      btn.disabled = false;
      btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
        </svg>
        Summarize & Create Continuation
      `;
    }
  });

  // Copy
  copyBtn.addEventListener('click', () => {
    const output = document.getElementById('summary-output');
    copyToClipboard(output.textContent);
  });
}

function displaySummarizeResults(adaptedPrompt, result) {
  const outputEl = document.getElementById('summary-output');
  outputEl.textContent = adaptedPrompt;
  outputEl.classList.remove('empty');

  // Stats
  const statsEl = document.getElementById('extraction-stats');
  const m = result.metadata;
  statsEl.innerHTML = `
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
      <div><strong>Format:</strong> ${m.format.replace('_', ' ')}</div>
      <div><strong>Turns:</strong> ${m.totalTurns} → ${m.compressedTurns}</div>
      <div><strong>Goals:</strong> ${m.goalsFound} found</div>
      <div><strong>Decisions:</strong> ${m.decisionsFound} found</div>
      <div><strong>Tasks:</strong> ${m.pendingTasksFound} pending</div>
      <div><strong>Code:</strong> ${m.codeBlocksFound} blocks</div>
    </div>
  `;
}

function reAdaptSummarizedPrompt() {
  if (!state.lastSummarizeResult) return;
  const adapted = adaptPrompt(state.lastSummarizeResult.continuationPrompt, state.summarizeModel);
  const outputEl = document.getElementById('summary-output');
  outputEl.textContent = adapted;
}


/* ══════════════════════════════════════════════
   SETTINGS
   ══════════════════════════════════════════════ */

function initSettingsPanel() {
  // Toggle bindings
  const toggleMap = {
    'setting-include-passport': 'includePassport',
    'setting-auto-mode': 'autoMode',
    'setting-show-memory': 'showMemory',
    'setting-show-suggested': 'showSuggested'
  };

  for (const [elId, key] of Object.entries(toggleMap)) {
    const el = document.getElementById(elId);
    if (el) {
      el.checked = state.settings[key];
      el.addEventListener('change', () => {
        state.settings[key] = el.checked;
        saveSettings();
      });
    }
  }

  // API provider
  const providerSelect = document.getElementById('setting-api-provider');
  const apiKeyField = document.getElementById('api-key-field');

  providerSelect.addEventListener('change', () => {
    state.settings.apiProvider = providerSelect.value;
    apiKeyField.style.display = providerSelect.value !== 'none' ? 'block' : 'none';
    saveSettings();
  });

  // API key
  const apiKeyInput = document.getElementById('setting-api-key');
  apiKeyInput.addEventListener('change', () => {
    state.settings.apiKey = apiKeyInput.value;
    saveSettings();
  });

  // Initialize visibility
  apiKeyField.style.display = state.settings.apiProvider !== 'none' ? 'block' : 'none';
  providerSelect.value = state.settings.apiProvider;



  // Reset Onboarding
  const resetOnboardingBtn = document.getElementById('reset-onboarding-btn');
  if (resetOnboardingBtn) {
    resetOnboardingBtn.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.remove('cloasta_onboarded', () => {
          showToast('Onboarding reset');
          document.getElementById('onboarding-overlay').style.display = 'flex';
        });
      } else {
        localStorage.removeItem('cloasta_onboarded');
        showToast('Onboarding reset');
        document.getElementById('onboarding-overlay').style.display = 'flex';
      }
    });
  }
}


/* ══════════════════════════════════════════════
   TEXT STATS (live word/char count)
   ══════════════════════════════════════════════ */

function initTextStats() {
  // Optimize input
  const optInput = document.getElementById('optimize-input');
  optInput.addEventListener('input', () => {
    const text = optInput.value;
    document.getElementById('optimize-word-count').textContent = countWords(text);
    document.getElementById('optimize-char-count').textContent = text.length;
  });

  // Summarize input
  const sumInput = document.getElementById('summarize-input');
  sumInput.addEventListener('input', () => {
    const text = sumInput.value;
    document.getElementById('summarize-word-count').textContent = countWords(text);
    document.getElementById('summarize-char-count').textContent = text.length;
  });
}


/* ══════════════════════════════════════════════
   EXPORT / IMPORT
   ══════════════════════════════════════════════ */

function initExportImport() {
  const exportBtn = document.getElementById('export-all-btn');
  const importBtn = document.getElementById('import-all-btn');
  const fileInput = document.getElementById('import-file-input');

  exportBtn.addEventListener('click', async () => {
    try {
      const data = {};

      // Get passport
      const { getPassport } = await import('../engine/aiPassport.js');
      data.passport = await getPassport();
      data.settings = state.settings;
      data.exportDate = new Date().toISOString();
      data.version = '1.0.0';

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cloasta-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);

      showToast('Data exported successfully!');
    } catch (e) {
      console.error('Export error:', e);
      showToast('Error exporting data');
    }
  });

  importBtn.addEventListener('click', () => {
    fileInput.click();
  });

  fileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const data = JSON.parse(text);

      // Import passport
      if (data.passport) {
        const { importPassport } = await import('../engine/aiPassport.js');
        await importPassport(JSON.stringify(data.passport));
      }

      // Import settings
      if (data.settings) {
        Object.assign(state.settings, data.settings);
        saveSettings();
        // Refresh settings UI
        initSettingsPanel();
      }

      showToast('Data imported successfully!');

      // Refresh passport UI
      initPassportUI();
    } catch (e) {
      console.error('Import error:', e);
      showToast('Error importing data. Check file format.');
    }

    // Reset file input
    fileInput.value = '';
  });
}


/* ══════════════════════════════════════════════
   UTILITIES
   ══════════════════════════════════════════════ */

function countWords(text) {
  if (!text || !text.trim()) return 0;
  return text.trim().split(/\s+/).length;
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied to clipboard!');
  }).catch(() => {
    // Fallback
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    showToast('Copied to clipboard!');
  });
}

function showToast(message, duration = 2500) {
  const toast = document.getElementById('toast');
  const msgEl = document.getElementById('toast-message');
  msgEl.textContent = message;
  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}


/* ══════════════════════════════════════════════
   STORAGE HELPERS
   ══════════════════════════════════════════════ */

function saveToStorage(key, value) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ [key]: value });
  } else {
    localStorage.setItem(key, JSON.stringify(value));
  }
}

function loadFromStorage(key, callback) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([key], (result) => {
      callback(result[key] || null);
    });
  } else {
    try {
      const val = localStorage.getItem(key);
      callback(val ? JSON.parse(val) : null);
    } catch (e) {
      callback(null);
    }
  }
}

function saveSettings() {
  saveToStorage('cloasta_settings', state.settings);
}

function loadSettings() {
  loadFromStorage('cloasta_settings', (settings) => {
    if (settings) {
      Object.assign(state.settings, settings);
    }
  });
}


/* ══════════════════════════════════════════════
   ONBOARDING
   ══════════════════════════════════════════════ */

function initOnboarding() {
  const overlay = document.getElementById('onboarding-overlay');
  const startBtn = document.getElementById('btn-start-cloasta');

  loadFromStorage('cloasta_onboarded', (onboarded) => {
    if (!onboarded) {
      overlay.style.display = 'flex';
    }
  });

  if (startBtn) {
    startBtn.addEventListener('click', () => {
      saveToStorage('cloasta_onboarded', true);
      overlay.style.display = 'none';
    });
  }
}

export { showToast, copyToClipboard, state };
