/**
 * Cloasta — AI Passport UI
 * 
 * Form-based editor for the AI Passport with tag inputs,
 * live preview, and import/export functionality.
 */

import {
  getPassport,
  savePassport,
  clearPassport,
  exportPassport,
  importPassport,
  generatePassportPreview,
  hasPassportData
} from '../engine/aiPassport.js';
import { showToast, copyToClipboard } from './app.js';

/**
 * Initialize the Passport UI tab
 */
async function initPassportUI() {
  const container = document.getElementById('passport-ui');
  if (!container) return;

  const passport = await getPassport();

  container.innerHTML = buildPassportHTML(passport);
  bindPassportEvents(passport);
}

/**
 * Build the passport form HTML
 */
function buildPassportHTML(passport) {
  return `
    <!-- Identity Section -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>👤</span> Identity
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-name">Name</label>
        <input type="text" class="input" id="passport-name" 
               value="${escapeHtml(passport.name || '')}" 
               placeholder="Your name">
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-role">Role</label>
        <input type="text" class="input" id="passport-role" 
               value="${escapeHtml(passport.role || '')}" 
               placeholder="e.g., Startup Founder, Software Engineer, Student">
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-industry">Industry</label>
        <input type="text" class="input" id="passport-industry" 
               value="${escapeHtml(passport.industry || '')}" 
               placeholder="e.g., SaaS, EdTech, Healthcare, Finance">
      </div>
    </div>

    <!-- Communication Section -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>💬</span> Communication
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-tone">Preferred Tone</label>
        <div class="select-wrapper">
          <select class="select" id="passport-tone">
            <option value="" ${!passport.preferredTone ? 'selected' : ''}>Select...</option>
            <option value="Professional" ${passport.preferredTone === 'Professional' ? 'selected' : ''}>Professional</option>
            <option value="Casual" ${passport.preferredTone === 'Casual' ? 'selected' : ''}>Casual</option>
            <option value="Academic" ${passport.preferredTone === 'Academic' ? 'selected' : ''}>Academic</option>
            <option value="Friendly" ${passport.preferredTone === 'Friendly' ? 'selected' : ''}>Friendly</option>
            <option value="Direct" ${passport.preferredTone === 'Direct' ? 'selected' : ''}>Direct</option>
            <option value="Creative" ${passport.preferredTone === 'Creative' ? 'selected' : ''}>Creative</option>
          </select>
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-comm-style">Communication Style</label>
        <div class="select-wrapper">
          <select class="select" id="passport-comm-style">
            <option value="" ${!passport.communicationStyle ? 'selected' : ''}>Select...</option>
            <option value="Direct" ${passport.communicationStyle === 'Direct' ? 'selected' : ''}>Direct — Get to the point</option>
            <option value="Detailed" ${passport.communicationStyle === 'Detailed' ? 'selected' : ''}>Detailed — Thorough explanations</option>
            <option value="Socratic" ${passport.communicationStyle === 'Socratic' ? 'selected' : ''}>Socratic — Guide with questions</option>
            <option value="Step-by-step" ${passport.communicationStyle === 'Step-by-step' ? 'selected' : ''}>Step-by-step — Methodical breakdown</option>
            <option value="Visual" ${passport.communicationStyle === 'Visual' ? 'selected' : ''}>Visual — Diagrams & examples</option>
          </select>
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-output-format">Output Format</label>
        <div class="select-wrapper">
          <select class="select" id="passport-output-format">
            <option value="" ${!passport.outputFormat ? 'selected' : ''}>Select...</option>
            <option value="Markdown" ${passport.outputFormat === 'Markdown' ? 'selected' : ''}>Markdown</option>
            <option value="Bullet Points" ${passport.outputFormat === 'Bullet Points' ? 'selected' : ''}>Bullet Points</option>
            <option value="Prose" ${passport.outputFormat === 'Prose' ? 'selected' : ''}>Prose / Paragraphs</option>
            <option value="Code-heavy" ${passport.outputFormat === 'Code-heavy' ? 'selected' : ''}>Code-heavy</option>
            <option value="Mixed" ${passport.outputFormat === 'Mixed' ? 'selected' : ''}>Mixed</option>
          </select>
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label" for="passport-detail-level">Detail Level</label>
        <div class="select-wrapper">
          <select class="select" id="passport-detail-level">
            <option value="" ${!passport.detailLevel ? 'selected' : ''}>Select...</option>
            <option value="High-level" ${passport.detailLevel === 'High-level' ? 'selected' : ''}>High-level — Brief overviews</option>
            <option value="Balanced" ${passport.detailLevel === 'Balanced' ? 'selected' : ''}>Balanced — Right amount of detail</option>
            <option value="Detailed" ${passport.detailLevel === 'Detailed' ? 'selected' : ''}>Detailed — In-depth analysis</option>
            <option value="Exhaustive" ${passport.detailLevel === 'Exhaustive' ? 'selected' : ''}>Exhaustive — Leave nothing out</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Context Section -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>🛠️</span> Context
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label">Tech Stack</label>
        <div class="tags-input-wrapper" id="tags-techStack" data-field="techStack">
          ${(passport.techStack || []).map(t => `
            <span class="tag" data-value="${escapeHtml(t)}">
              ${escapeHtml(t)}
              <button class="tag-remove" data-value="${escapeHtml(t)}">×</button>
            </span>
          `).join('')}
          <input type="text" class="tags-input" placeholder="Type & press Enter..." id="input-techStack">
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label">Expertise Areas</label>
        <div class="tags-input-wrapper" id="tags-expertise" data-field="expertise">
          ${(passport.expertise || []).map(t => `
            <span class="tag" data-value="${escapeHtml(t)}">
              ${escapeHtml(t)}
              <button class="tag-remove" data-value="${escapeHtml(t)}">×</button>
            </span>
          `).join('')}
          <input type="text" class="tags-input" placeholder="Type & press Enter..." id="input-expertise">
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label">Current Projects</label>
        <div class="tags-input-wrapper" id="tags-currentProjects" data-field="currentProjects">
          ${(passport.currentProjects || []).map(t => `
            <span class="tag" data-value="${escapeHtml(t)}">
              ${escapeHtml(t)}
              <button class="tag-remove" data-value="${escapeHtml(t)}">×</button>
            </span>
          `).join('')}
          <input type="text" class="tags-input" placeholder="Type & press Enter..." id="input-currentProjects">
        </div>
      </div>
    </div>

    <!-- Long-term Memory Section -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>🧠</span> Long-term Memory
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label">Ongoing Goals</label>
        <div class="tags-input-wrapper" id="tags-ongoingGoals" data-field="ongoingGoals">
          ${(passport.ongoingGoals || []).map(t => `
            <span class="tag" data-value="${escapeHtml(t)}">
              ${escapeHtml(t)}
              <button class="tag-remove" data-value="${escapeHtml(t)}">×</button>
            </span>
          `).join('')}
          <input type="text" class="tags-input" placeholder="Type & press Enter..." id="input-ongoingGoals">
        </div>
      </div>

      <div class="passport-field">
        <label class="form-label">Important Facts</label>
        <div class="tags-input-wrapper" id="tags-importantFacts" data-field="importantFacts">
          ${(passport.importantFacts || []).map(t => `
            <span class="tag" data-value="${escapeHtml(t)}">
              ${escapeHtml(t)}
              <button class="tag-remove" data-value="${escapeHtml(t)}">×</button>
            </span>
          `).join('')}
          <input type="text" class="tags-input" placeholder="Type & press Enter..." id="input-importantFacts">
        </div>
      </div>
    </div>

    <!-- Preview Section -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>👁️</span> Prompt Preview
        </div>
        <button class="btn-icon" id="copy-passport-preview" title="Copy preview">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
          </svg>
        </button>
      </div>
      <p class="card-description mb-md">This is how your passport context appears when injected into prompts:</p>
      <div class="passport-preview" id="passport-preview">
        ${escapeHtml(generatePassportPreview(passport))}
      </div>
    </div>

    <!-- Actions -->
    <div class="card">
      <div class="card-header">
        <div class="card-title">
          <span>📦</span> Passport Actions
        </div>
      </div>
      <div class="flex flex-col gap-sm">
        <button class="btn btn-primary btn-block" id="save-passport-btn">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Save Passport
        </button>
        <div class="flex gap-sm">
          <button class="btn btn-secondary" id="export-passport-btn" style="flex: 1;">Export JSON</button>
          <button class="btn btn-secondary" id="import-passport-btn" style="flex: 1;">Import JSON</button>
        </div>
        <button class="btn btn-secondary btn-block" id="clear-passport-btn" style="color: var(--error-text);">
          Clear All Data
        </button>
      </div>
      <input type="file" id="passport-import-file" accept=".json" style="display: none;">
    </div>
  `;
}


/**
 * Bind all passport form events
 */
function bindPassportEvents(passport) {
  // Track current passport state
  let currentPassport = { ...passport };

  // ── Tag Inputs ──
  const tagFields = ['techStack', 'expertise', 'currentProjects', 'ongoingGoals', 'importantFacts'];

  for (const field of tagFields) {
    const input = document.getElementById(`input-${field}`);
    const wrapper = document.getElementById(`tags-${field}`);

    if (!input || !wrapper) continue;

    // Focus wrapper when clicking on it
    wrapper.addEventListener('click', () => input.focus());

    // Add tag on Enter
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        e.preventDefault();
        const value = input.value.trim();

        if (!currentPassport[field]) currentPassport[field] = [];
        if (!currentPassport[field].includes(value)) {
          currentPassport[field].push(value);

          // Add tag element
          const tag = document.createElement('span');
          tag.className = 'tag';
          tag.dataset.value = value;
          tag.innerHTML = `${escapeHtml(value)}<button class="tag-remove" data-value="${escapeHtml(value)}">×</button>`;
          wrapper.insertBefore(tag, input);

          // Bind remove
          tag.querySelector('.tag-remove').addEventListener('click', () => {
            currentPassport[field] = currentPassport[field].filter(v => v !== value);
            tag.remove();
            updatePreview(currentPassport);
          });
        }

        input.value = '';
        updatePreview(currentPassport);
      }

      // Remove last tag on Backspace if input is empty
      if (e.key === 'Backspace' && !input.value) {
        const tags = wrapper.querySelectorAll('.tag');
        if (tags.length > 0) {
          const lastTag = tags[tags.length - 1];
          const value = lastTag.dataset.value;
          currentPassport[field] = currentPassport[field].filter(v => v !== value);
          lastTag.remove();
          updatePreview(currentPassport);
        }
      }
    });

    // Bind existing tag remove buttons
    wrapper.querySelectorAll('.tag-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const value = btn.dataset.value;
        currentPassport[field] = currentPassport[field].filter(v => v !== value);
        btn.closest('.tag').remove();
        updatePreview(currentPassport);
      });
    });
  }

  // ── Save Button ──
  const saveBtn = document.getElementById('save-passport-btn');
  saveBtn.addEventListener('click', async () => {
    // Gather all form values
    currentPassport.name = document.getElementById('passport-name').value.trim();
    currentPassport.role = document.getElementById('passport-role').value.trim();
    currentPassport.industry = document.getElementById('passport-industry').value.trim();
    currentPassport.preferredTone = document.getElementById('passport-tone').value;
    currentPassport.communicationStyle = document.getElementById('passport-comm-style').value;
    currentPassport.outputFormat = document.getElementById('passport-output-format').value;
    currentPassport.detailLevel = document.getElementById('passport-detail-level').value;

    try {
      await savePassport(currentPassport);
      showToast('Passport saved successfully!');
      updatePreview(currentPassport);
    } catch (e) {
      console.error('Save error:', e);
      showToast('Error saving passport');
    }
  });

  // ── Export Button ──
  const exportBtn = document.getElementById('export-passport-btn');
  exportBtn.addEventListener('click', async () => {
    try {
      const json = await exportPassport();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `cloasta-passport-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Passport exported!');
    } catch (e) {
      showToast('Error exporting passport');
    }
  });

  // ── Import Button ──
  const importBtn = document.getElementById('import-passport-btn');
  const importFile = document.getElementById('passport-import-file');

  importBtn.addEventListener('click', () => importFile.click());

  importFile.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const imported = await importPassport(text);
      currentPassport = imported;
      // Re-render the entire UI
      await initPassportUI();
      showToast('Passport imported successfully!');
    } catch (e) {
      showToast('Error importing passport: ' + e.message);
    }
    importFile.value = '';
  });

  // ── Clear Button ──
  const clearBtn = document.getElementById('clear-passport-btn');
  clearBtn.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear all passport data? This cannot be undone.')) {
      try {
        const empty = await clearPassport();
        currentPassport = empty;
        await initPassportUI();
        showToast('Passport cleared');
      } catch (e) {
        showToast('Error clearing passport');
      }
    }
  });

  // ── Copy Preview ──
  const copyPreviewBtn = document.getElementById('copy-passport-preview');
  copyPreviewBtn.addEventListener('click', () => {
    const preview = document.getElementById('passport-preview');
    copyToClipboard(preview.textContent);
  });

  // ── Live preview on input changes ──
  ['passport-name', 'passport-role', 'passport-industry', 'passport-tone',
    'passport-comm-style', 'passport-output-format', 'passport-detail-level'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', () => {
        currentPassport.name = document.getElementById('passport-name').value.trim();
        currentPassport.role = document.getElementById('passport-role').value.trim();
        currentPassport.industry = document.getElementById('passport-industry').value.trim();
        currentPassport.preferredTone = document.getElementById('passport-tone').value;
        currentPassport.communicationStyle = document.getElementById('passport-comm-style').value;
        currentPassport.outputFormat = document.getElementById('passport-output-format').value;
        currentPassport.detailLevel = document.getElementById('passport-detail-level').value;
        updatePreview(currentPassport);
      });
      el.addEventListener('change', () => {
        currentPassport[id.replace('passport-', '').replace('-', '')] = el.value;
        updatePreview(currentPassport);
      });
    }
  });
}

/**
 * Update the passport preview
 */
function updatePreview(passport) {
  const previewEl = document.getElementById('passport-preview');
  if (previewEl) {
    previewEl.textContent = generatePassportPreview(passport);
  }
}

/**
 * HTML escape helper
 */
function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}


export { initPassportUI };
