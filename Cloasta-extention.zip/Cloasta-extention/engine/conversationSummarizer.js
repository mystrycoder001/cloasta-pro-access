/**
 * Cloasta — Conversation Summarizer
 * 
 * Transforms long AI conversation exports into continuation-ready prompts.
 * Supports raw paste, markdown-formatted conversations, and ChatGPT JSON exports.
 * 
 * Pipeline:
 *  1. Format Detection
 *  2. Turn Parsing (user/assistant speaker separation)
 *  3. Key Extraction (goals, decisions, tasks, facts, code)
 *  4. Smart Compression (importance ranking)
 *  5. Continuation Prompt Generation
 */

/* ══════════════════════════════════════════════
   FORMAT DETECTION
   ══════════════════════════════════════════════ */

const FORMATS = {
  CHATGPT_JSON: 'chatgpt_json',
  MARKDOWN_CHAT: 'markdown_chat',
  LABELED_TURNS: 'labeled_turns',
  RAW_PASTE: 'raw_paste'
};

/**
 * Detect the format of the conversation input
 */
function detectFormat(input) {
  const trimmed = input.trim();

  // ChatGPT JSON export
  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    try {
      JSON.parse(trimmed);
      return FORMATS.CHATGPT_JSON;
    } catch (e) {
      // Not valid JSON
    }
  }

  // Markdown-style conversation (### User / ### Assistant)
  if (/^#{1,3}\s*(user|human|assistant|ai|system)/mi.test(trimmed)) {
    return FORMATS.MARKDOWN_CHAT;
  }

  // Labeled turns (User: ... / Assistant: ...)
  if (/^(user|human|me|assistant|ai|chatgpt|claude|gemini|you)\s*:/mi.test(trimmed)) {
    return FORMATS.LABELED_TURNS;
  }

  // Bold-labeled turns (**User**: ... / **Assistant**: ...)
  if (/\*\*(user|human|assistant|ai)\*\*/i.test(trimmed)) {
    return FORMATS.LABELED_TURNS;
  }

  return FORMATS.RAW_PASTE;
}


/* ══════════════════════════════════════════════
   TURN PARSING
   ══════════════════════════════════════════════ */

/**
 * Parse conversation into structured turns
 * @returns {Array<{role: 'user'|'assistant', content: string}>}
 */
function parseTurns(input, format) {
  switch (format) {
    case FORMATS.CHATGPT_JSON:
      return parseChatGPTJSON(input);
    case FORMATS.MARKDOWN_CHAT:
      return parseMarkdownChat(input);
    case FORMATS.LABELED_TURNS:
      return parseLabeledTurns(input);
    case FORMATS.RAW_PASTE:
    default:
      return parseRawPaste(input);
  }
}

function parseChatGPTJSON(input) {
  try {
    const data = JSON.parse(input);
    const turns = [];

    // Handle ChatGPT export format (array of messages or nested structure)
    const messages = Array.isArray(data) ? data :
      data.mapping ? Object.values(data.mapping)
        .filter(m => m.message && m.message.content)
        .sort((a, b) => (a.message.create_time || 0) - (b.message.create_time || 0))
        .map(m => m.message) :
      data.messages || [];

    for (const msg of messages) {
      const role = (msg.role || msg.author?.role || 'user').toLowerCase();
      const content = typeof msg.content === 'string' ? msg.content :
        msg.content?.parts?.join('\n') || '';

      if (content.trim() && (role === 'user' || role === 'assistant')) {
        turns.push({
          role: role === 'user' ? 'user' : 'assistant',
          content: content.trim()
        });
      }
    }

    return turns;
  } catch (e) {
    // Fallback to raw parse
    return parseRawPaste(input);
  }
}

function parseMarkdownChat(input) {
  const turns = [];
  const sections = input.split(/^#{1,3}\s*/m).filter(s => s.trim());

  for (const section of sections) {
    const firstLine = section.split('\n')[0].toLowerCase().trim();
    const content = section.split('\n').slice(1).join('\n').trim();

    if (!content) continue;

    const isUser = /^(user|human|me)/.test(firstLine);
    const isAssistant = /^(assistant|ai|chatgpt|claude|gemini|system)/.test(firstLine);

    if (isUser || isAssistant) {
      turns.push({
        role: isUser ? 'user' : 'assistant',
        content
      });
    }
  }

  return turns;
}

function parseLabeledTurns(input) {
  const turns = [];

  // Split on speaker labels
  const pattern = /(?:^|\n)(?:\*\*)?(user|human|me|assistant|ai|chatgpt|claude|gemini|you)(?:\*\*)?\s*:\s*/gi;
  const parts = input.split(pattern).filter(s => s.trim());

  for (let i = 0; i < parts.length - 1; i += 2) {
    const speaker = parts[i].toLowerCase().trim();
    const content = (parts[i + 1] || '').trim();

    if (!content) continue;

    const isUser = ['user', 'human', 'me'].includes(speaker);
    turns.push({
      role: isUser ? 'user' : 'assistant',
      content
    });
  }

  return turns;
}

function parseRawPaste(input) {
  // Best-effort: treat the whole thing as a single user message
  // or try to split by paragraph breaks
  const paragraphs = input.split(/\n{2,}/).filter(p => p.trim());

  if (paragraphs.length <= 1) {
    return [{ role: 'user', content: input.trim() }];
  }

  // Alternate between user and assistant if we can detect a pattern
  const turns = [];
  let currentRole = 'user';

  for (const para of paragraphs) {
    // Simple heuristic: longer, more structured paragraphs are likely assistant
    const isLikelyAssistant = para.length > 200 || para.includes('```') ||
      para.includes('1.') || (para.match(/\n-/g) || []).length >= 2;

    if (isLikelyAssistant && currentRole === 'user' && turns.length > 0) {
      currentRole = 'assistant';
    } else if (!isLikelyAssistant && currentRole === 'assistant') {
      currentRole = 'user';
    }

    turns.push({ role: currentRole, content: para.trim() });

    // Toggle for next iteration
    currentRole = currentRole === 'user' ? 'assistant' : 'user';
  }

  return turns;
}


/* ══════════════════════════════════════════════
   KEY EXTRACTION
   ══════════════════════════════════════════════ */

/**
 * Extract important elements from the conversation
 */
function extractKeyElements(turns) {
  const allUserContent = turns.filter(t => t.role === 'user').map(t => t.content).join('\n');
  const allAssistantContent = turns.filter(t => t.role === 'assistant').map(t => t.content).join('\n');
  const allContent = turns.map(t => t.content).join('\n');

  return {
    goals: extractGoals(allUserContent),
    decisions: extractDecisions(allContent),
    pendingTasks: extractPendingTasks(allContent),
    importantFacts: extractFacts(allContent),
    codeSnippets: extractCode(allAssistantContent),
    unresolvedQuestions: extractQuestions(allContent)
  };
}

function extractGoals(text) {
  const goals = [];
  const patterns = [
    /(?:i want|i need|my goal is|i'm trying to|help me|can you|please)\s+([^.!?\n]{15,100})/gi,
    /(?:objective|goal|aim|target):\s*([^.!?\n]{10,100})/gi
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(text)) !== null) {
      const goal = match[1].trim();
      if (goal && !goals.some(g => g.toLowerCase() === goal.toLowerCase())) {
        goals.push(goal);
      }
    }
  }

  return goals.slice(0, 5);
}

function extractDecisions(text) {
  const decisions = [];
  const patterns = [
    /(?:(?:i|we) (?:decided|chose|went with|agreed|settled on|confirmed))\s+([^.!?\n]{10,120})/gi,
    /(?:let's go with|the plan is|we'll use|final (?:decision|choice|answer))[:.]?\s*([^.!?\n]{10,120})/gi,
    /(?:decision|conclusion):\s*([^.!?\n]{10,120})/gi
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(text)) !== null) {
      const decision = match[1].trim();
      if (decision && !decisions.some(d => d.toLowerCase() === decision.toLowerCase())) {
        decisions.push(decision);
      }
    }
  }

  return decisions.slice(0, 5);
}

function extractPendingTasks(text) {
  const tasks = [];
  const patterns = [
    /(?:todo|to-do|next step|still need to|haven't done|remaining|left to do)[:.]?\s*([^.!?\n]{10,100})/gi,
    /(?:need to|should|will|must|have to)\s+([^.!?\n]{10,100})/gi,
    /- \[ \]\s*(.+)/g  // Markdown unchecked boxes
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(text)) !== null) {
      const task = match[1].trim();
      if (task && !tasks.some(t => t.toLowerCase() === task.toLowerCase())) {
        tasks.push(task);
      }
    }
  }

  return tasks.slice(0, 8);
}

function extractFacts(text) {
  const facts = [];
  const patterns = [
    /(?:important|key|note|remember|critical|fyi|for reference)[:.]?\s*([^.!?\n]{10,120})/gi
  ];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(text)) !== null) {
      facts.push(match[1].trim());
    }
  }

  return [...new Set(facts)].slice(0, 5);
}

function extractCode(text) {
  const codeBlocks = [];
  const pattern = /```(\w*)\n([\s\S]*?)```/g;

  let match;
  while ((match = pattern.exec(text)) !== null) {
    codeBlocks.push({
      language: match[1] || 'unknown',
      code: match[2].trim().substring(0, 500) // Limit size
    });
  }

  // Keep only the last 3 code blocks (most recent/relevant)
  return codeBlocks.slice(-3);
}

function extractQuestions(text) {
  const questions = [];
  const sentences = text.split(/[.!?\n]+/);

  for (const sentence of sentences) {
    const trimmed = sentence.trim();
    if (trimmed.endsWith('?') && trimmed.length > 15) {
      questions.push(trimmed + '?');
    }
  }

  // Prioritize user questions at the end (more likely unresolved)
  return questions.slice(-5);
}


/* ══════════════════════════════════════════════
   SMART COMPRESSION
   ══════════════════════════════════════════════ */

/**
 * Rank turns by importance and create compressed version
 */
function compressConversation(turns, keyElements) {
  // Score each turn for importance
  const scored = turns.map((turn, index) => {
    let score = 0;

    // Recency bias: later turns are more important
    score += (index / turns.length) * 3;

    // User turns with questions are important
    if (turn.role === 'user' && turn.content.includes('?')) score += 2;

    // Turns with decisions or key facts
    const lowerContent = turn.content.toLowerCase();
    if (lowerContent.includes('decided') || lowerContent.includes('chose') || lowerContent.includes('agree')) score += 3;

    // Turns with code
    if (turn.content.includes('```')) score += 2;

    // Turns with action items
    if (lowerContent.includes('todo') || lowerContent.includes('next step') || lowerContent.includes('need to')) score += 2;

    // Very short turns (acknowledgments) are less important
    if (turn.content.length < 30) score -= 2;

    // Very long assistant responses get slight bonus (they contain substance)
    if (turn.role === 'assistant' && turn.content.length > 300) score += 1;

    return { ...turn, score, index };
  });

  // Sort by score, keep top 60% of turns
  const keepCount = Math.max(Math.ceil(turns.length * 0.6), 3);
  const important = scored
    .sort((a, b) => b.score - a.score)
    .slice(0, keepCount)
    .sort((a, b) => a.index - b.index); // Restore chronological order

  return important;
}


/* ══════════════════════════════════════════════
   CONTINUATION PROMPT GENERATION
   ══════════════════════════════════════════════ */

/**
 * Generate a self-contained continuation prompt
 */
function buildContinuationPrompt(keyElements, compressedTurns) {
  let prompt = '';

  // Context Summary
  prompt += `## Context Summary\n`;
  prompt += `This continues a previous conversation. Here is the essential context:\n\n`;

  // Compressed conversation highlights
  if (compressedTurns.length > 0) {
    const highlights = compressedTurns.map(turn => {
      const speaker = turn.role === 'user' ? '**User**' : '**Assistant**';
      const content = turn.content.length > 250
        ? turn.content.substring(0, 250).trim() + '...'
        : turn.content;
      return `${speaker}: ${content}`;
    });
    prompt += highlights.join('\n\n') + '\n\n';
  }

  // Goals
  if (keyElements.goals.length > 0) {
    prompt += `## Goals\n`;
    prompt += keyElements.goals.map(g => `- ${g}`).join('\n') + '\n\n';
  }

  // Decisions Made
  if (keyElements.decisions.length > 0) {
    prompt += `## Decisions Made\n`;
    prompt += keyElements.decisions.map(d => `- ${d}`).join('\n') + '\n\n';
  }

  // Pending Tasks
  if (keyElements.pendingTasks.length > 0) {
    prompt += `## Pending Tasks\n`;
    prompt += keyElements.pendingTasks.map(t => `- [ ] ${t}`).join('\n') + '\n\n';
  }

  // Important Facts
  if (keyElements.importantFacts.length > 0) {
    prompt += `## Important Context\n`;
    prompt += keyElements.importantFacts.map(f => `- ${f}`).join('\n') + '\n\n';
  }

  // Code Context
  if (keyElements.codeSnippets.length > 0) {
    prompt += `## Relevant Code\n`;
    for (const snippet of keyElements.codeSnippets) {
      prompt += `\`\`\`${snippet.language}\n${snippet.code}\n\`\`\`\n\n`;
    }
  }

  // Unresolved Questions
  if (keyElements.unresolvedQuestions.length > 0) {
    prompt += `## Unresolved Questions\n`;
    prompt += keyElements.unresolvedQuestions.map(q => `- ${q}`).join('\n') + '\n\n';
  }

  // Continuation instruction
  prompt += `## Continue From Here\n`;
  prompt += `Please continue this conversation naturally. You have the full context above. `;

  if (keyElements.pendingTasks.length > 0) {
    prompt += `Focus on addressing the pending tasks listed above.`;
  } else if (keyElements.unresolvedQuestions.length > 0) {
    prompt += `Start by addressing the unresolved questions above.`;
  } else {
    prompt += `Pick up where the conversation left off and help the user achieve their goals.`;
  }

  return prompt.trim();
}


/* ══════════════════════════════════════════════
   MAIN SUMMARIZER
   ══════════════════════════════════════════════ */

/**
 * Main summarization function — full pipeline
 * 
 * @param {string} rawConversation - The raw conversation text
 * @returns {object} - { continuationPrompt, keyElements, metadata }
 */
function summarizeConversation(rawConversation) {
  // Step 1: Detect format
  const format = detectFormat(rawConversation);

  // Step 2: Parse turns
  const turns = parseTurns(rawConversation, format);

  // Step 3: Extract key elements
  const keyElements = extractKeyElements(turns);

  // Step 4: Smart compression
  const compressed = compressConversation(turns, keyElements);

  // Step 5: Build continuation prompt
  const continuationPrompt = buildContinuationPrompt(keyElements, compressed);

  return {
    continuationPrompt,
    keyElements,
    metadata: {
      format,
      totalTurns: turns.length,
      compressedTurns: compressed.length,
      compressionRatio: Math.round((1 - compressed.length / Math.max(turns.length, 1)) * 100),
      goalsFound: keyElements.goals.length,
      decisionsFound: keyElements.decisions.length,
      pendingTasksFound: keyElements.pendingTasks.length,
      codeBlocksFound: keyElements.codeSnippets.length,
      timestamp: new Date().toISOString()
    }
  };
}


export { summarizeConversation, detectFormat, parseTurns, extractKeyElements, FORMATS };
