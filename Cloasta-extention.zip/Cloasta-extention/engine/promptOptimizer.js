/**
 * Cloasta — Prompt Optimizer Engine (Hybrid)
 * 
 * Rule-based pipeline that transforms messy user input into structured,
 * optimized prompts. Works entirely offline — no API needed.
 * 
 * Pipeline:
 *  1. Input Classification
 *  2. Noise Removal
 *  3. Intent & Structure Extraction
 *  4. Context Compression
 *  5. AI Passport Merge
 *  6. Mode Application
 *  7. Final Assembly
 */

import { detectMode, applyModeTemplate } from './templates.js';
import { getPassport } from './aiPassport.js';

/* ══════════════════════════════════════════════
   INPUT CLASSIFICATION
   ══════════════════════════════════════════════ */

const INPUT_TYPES = {
  VOICE_TRANSCRIPT: 'voice_transcript',
  CONVERSATION: 'conversation',
  CODE_REQUEST: 'code_request',
  RAW_IDEA: 'raw_idea',
  RESEARCH_QUERY: 'research_query',
  STRUCTURED_PROMPT: 'structured_prompt'
};

/**
 * Classify the type of input provided
 */
function classifyInput(input) {
  const lower = input.toLowerCase();
  const lines = input.split('\n').filter(l => l.trim());

  // Voice transcript indicators
  const voiceMarkers = ['um', 'uh', 'like,', 'you know', 'basically', 'so basically', 'i mean', 'kind of', 'sort of'];
  const voiceScore = voiceMarkers.reduce((score, marker) => {
    const regex = new RegExp(`\\b${marker}\\b`, 'gi');
    return score + (lower.match(regex) || []).length;
  }, 0);
  if (voiceScore >= 3) return INPUT_TYPES.VOICE_TRANSCRIPT;

  // Conversation indicators
  const conversationPatterns = [
    /^(user|human|assistant|ai|chatgpt|claude|gemini)\s*:/mi,
    /^(me|you)\s*:/mi,
    /^\*\*(user|assistant|human)\*\*/mi,
    /^>\s*(user|assistant)/mi
  ];
  const hasConversation = conversationPatterns.some(p => p.test(input));
  if (hasConversation || (lines.length > 6 && input.includes('?') && input.includes(':'))) {
    return INPUT_TYPES.CONVERSATION;
  }

  // Code request indicators
  const codeMarkers = ['function', 'class ', 'import ', 'const ', 'let ', 'var ', 'def ', 'return ', 'console.log', 'print(', '```', 'api', 'endpoint', 'database', 'sql', 'react', 'python', 'javascript', 'typescript'];
  const codeScore = codeMarkers.reduce((score, marker) => {
    return score + (lower.includes(marker) ? 1 : 0);
  }, 0);
  if (codeScore >= 3) return INPUT_TYPES.CODE_REQUEST;

  // Structured prompt (already has some structure)
  const structureMarkers = ['##', '**objective', '**goal', '**context', '**task', '- ', '1.', '2.', '3.'];
  const structureScore = structureMarkers.reduce((score, marker) => {
    return score + (lower.includes(marker) ? 1 : 0);
  }, 0);
  if (structureScore >= 3) return INPUT_TYPES.STRUCTURED_PROMPT;

  // Research query
  const researchMarkers = ['research', 'study', 'evidence', 'literature', 'hypothesis', 'data', 'analysis', 'findings', 'compare', 'evaluate'];
  const researchScore = researchMarkers.reduce((score, marker) => {
    return score + (lower.includes(marker) ? 1 : 0);
  }, 0);
  if (researchScore >= 3) return INPUT_TYPES.RESEARCH_QUERY;

  // Default: raw idea
  return INPUT_TYPES.RAW_IDEA;
}


/* ══════════════════════════════════════════════
   NOISE REMOVAL
   ══════════════════════════════════════════════ */

/**
 * Remove filler words, stutters, and noise from input
 */
function removeNoise(input, inputType) {
  let cleaned = input;

  // Voice transcript specific cleaning
  if (inputType === INPUT_TYPES.VOICE_TRANSCRIPT) {
    // Remove filler words (careful not to remove from meaningful context)
    const fillers = [
      /\b(um+|uh+|hmm+|er+|ah+)\b[,.]?\s*/gi,
      /\b(you know)\b[,.]?\s*/gi,
      /\b(i mean)\b[,.]?\s*/gi,
      /\b(kind of|sort of)\b/gi,
      /\b(basically|essentially)\s+/gi,
      /\b(so basically)\s+/gi,
      /\b(right\?)\s*/gi,
      /\b(like,?\s+)/gi
    ];
    
    for (const filler of fillers) {
      cleaned = cleaned.replace(filler, ' ');
    }
  }

  // Universal cleaning
  // Remove excessive whitespace
  cleaned = cleaned.replace(/[ \t]+/g, ' ');
  // Remove excessive newlines (3+ → 2)
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
  // Remove trailing whitespace per line
  cleaned = cleaned.replace(/[ \t]+$/gm, '');
  // Remove leading/trailing whitespace
  cleaned = cleaned.trim();

  return cleaned;
}


/* ══════════════════════════════════════════════
   INTENT & STRUCTURE EXTRACTION
   ══════════════════════════════════════════════ */

/**
 * Extract the core intent, context, and structure from cleaned input
 */
function extractStructure(input) {
  const lines = input.split('\n').filter(l => l.trim());
  const fullText = input.toLowerCase();

  // Extract objective (first meaningful sentence or question)
  let objective = '';
  let context = '';
  let constraints = '';
  let details = '';

  // Try to find explicit objective markers
  const objectivePatterns = [
    /(?:i want|i need|please|help me|can you|could you|create|build|make|write|design|develop|implement|fix|debug|explain|analyze|research|find)\s+(.+?)(?:\.|$)/i,
    /(?:goal|objective|task|request):\s*(.+?)(?:\.|$)/i,
    /(?:how (?:do|can|to|would)|what (?:is|are|would)|why (?:does|is|do))\s+(.+?)(?:\?|$)/i
  ];

  for (const pattern of objectivePatterns) {
    const match = input.match(pattern);
    if (match) {
      objective = match[0].trim();
      break;
    }
  }

  // If no explicit objective, use the first substantial sentence
  if (!objective && lines.length > 0) {
    objective = lines[0].trim();
    // If first line is very short, combine with second
    if (objective.length < 30 && lines.length > 1) {
      objective = lines.slice(0, 2).join(' ').trim();
    }
  }

  // Extract constraints (sentences with limiting/requirement language)
  const constraintPatterns = [
    /(?:must|should|need to|has to|require|don't|avoid|limit|only|no more than|at least|within|maximum|minimum|must not|cannot|shouldn't)\s+[^.!?\n]+[.!?]?/gi
  ];
  const constraintMatches = [];
  for (const pattern of constraintPatterns) {
    const matches = input.match(pattern);
    if (matches) constraintMatches.push(...matches);
  }
  if (constraintMatches.length > 0) {
    // Deduplicate
    const unique = [...new Set(constraintMatches.map(c => c.trim()))];
    constraints = unique.map(c => `- ${c}`).join('\n');
  }

  // Everything else becomes context/details
  const usedText = [objective, ...constraintMatches].join(' ').toLowerCase();
  const remainingLines = lines.filter(line => {
    const lower = line.toLowerCase().trim();
    return lower.length > 10 && !usedText.includes(lower);
  });

  if (remainingLines.length > 0) {
    // Split remaining into context (background info) and details (specifics)
    const midpoint = Math.ceil(remainingLines.length / 2);
    context = remainingLines.slice(0, midpoint).join('\n');
    details = remainingLines.slice(midpoint).join('\n');
  }

  return { objective, context, constraints, details };
}


/* ══════════════════════════════════════════════
   CONTEXT COMPRESSION
   ══════════════════════════════════════════════ */

/**
 * Compress and deduplicate content while preserving meaning
 */
function compressContext(promptData) {
  const compressed = { ...promptData };

  // Deduplicate: check if context repeats objective
  if (compressed.context && compressed.objective) {
    const objWords = new Set(compressed.objective.toLowerCase().split(/\s+/));
    const contextWords = compressed.context.toLowerCase().split(/\s+/);
    const overlap = contextWords.filter(w => objWords.has(w)).length / contextWords.length;
    
    // If >60% overlap, the context is just repeating the objective
    if (overlap > 0.6) {
      compressed.context = '';
    }
  }

  // Deduplicate: check if details repeats context
  if (compressed.details && compressed.context) {
    const ctxWords = new Set(compressed.context.toLowerCase().split(/\s+/));
    const detailWords = compressed.details.toLowerCase().split(/\s+/);
    const overlap = detailWords.filter(w => ctxWords.has(w)).length / Math.max(detailWords.length, 1);

    if (overlap > 0.6) {
      compressed.details = '';
    }
  }

  // Trim very long sections (keep under 500 chars each for compression)
  const maxSectionLen = 800;
  for (const key of ['context', 'details', 'constraints']) {
    if (compressed[key] && compressed[key].length > maxSectionLen) {
      // Keep first and last portions
      const text = compressed[key];
      const firstHalf = text.substring(0, maxSectionLen * 0.6);
      const lastBit = text.substring(text.length - maxSectionLen * 0.3);
      compressed[key] = firstHalf.trim() + '\n...\n' + lastBit.trim();
    }
  }

  return compressed;
}


/* ══════════════════════════════════════════════
   PASSPORT MERGE
   ══════════════════════════════════════════════ */

/**
 * Inject relevant AI Passport context into the prompt
 */
function mergePassport(promptText, passport) {
  if (!passport || Object.keys(passport).length === 0) return promptText;

  let passportContext = '';

  if (passport.role) {
    passportContext += `**Role:** ${passport.role}\n`;
  }
  if (passport.preferredTone) {
    passportContext += `**Preferred Tone:** ${passport.preferredTone}\n`;
  }
  if (passport.communicationStyle) {
    passportContext += `**Communication Style:** ${passport.communicationStyle}\n`;
  }
  if (passport.techStack && passport.techStack.length > 0) {
    passportContext += `**Tech Stack:** ${passport.techStack.join(', ')}\n`;
  }
  if (passport.expertise && passport.expertise.length > 0) {
    passportContext += `**Expertise:** ${passport.expertise.join(', ')}\n`;
  }
  if (passport.industry) {
    passportContext += `**Industry:** ${passport.industry}\n`;
  }
  if (passport.outputFormat) {
    passportContext += `**Preferred Output Format:** ${passport.outputFormat}\n`;
  }
  if (passport.importantFacts && passport.importantFacts.length > 0) {
    passportContext += `**Key Facts:**\n${passport.importantFacts.map(f => `- ${f}`).join('\n')}\n`;
  }
  if (passport.currentProjects && passport.currentProjects.length > 0) {
    passportContext += `**Active Projects:** ${passport.currentProjects.join(', ')}\n`;
  }

  if (passportContext) {
    return `## User Profile\n${passportContext}\n---\n\n${promptText}`;
  }

  return promptText;
}


/* ══════════════════════════════════════════════
   MAIN OPTIMIZER PIPELINE
   ══════════════════════════════════════════════ */

/**
 * Main optimization function — runs the full pipeline
 * 
 * @param {string} rawInput - The messy user input
 * @param {object} options - Configuration options
 * @param {string} options.mode - Force a specific mode (auto-detected if not set)
 * @param {boolean} options.includePassport - Whether to merge AI Passport (default: true)
 * @param {string} options.targetModel - Target AI model for adapter formatting
 * @returns {object} - { optimizedPrompt, contextSummary, memoryPoints, suggestedNext, metadata }
 */
async function optimizePrompt(rawInput, options = {}) {
  const {
    mode = null,
    includePassport = true,
    targetModel = 'generic'
  } = options;

  // ── Step 1: Classify Input ──
  const inputType = classifyInput(rawInput);

  // ── Step 2: Remove Noise ──
  const cleaned = removeNoise(rawInput, inputType);

  // ── Step 3: Extract Structure ──
  const promptData = extractStructure(cleaned);

  // ── Step 4: Compress Context ──
  const compressed = compressContext(promptData);

  // ── Step 5: Detect or Apply Mode ──
  const selectedMode = mode || detectMode(cleaned);

  // ── Step 6: Apply Mode Template ──
  let optimized = applyModeTemplate(selectedMode, compressed);

  // ── Step 7: Merge AI Passport ──
  if (includePassport) {
    try {
      const passport = await getPassport();
      optimized = mergePassport(optimized, passport);
    } catch (e) {
      // Passport not available, continue without it
      // AI Passport not available, skipping merge.
    }
  }

  // ── Build Output ──
  const contextSummary = buildContextSummary(compressed, selectedMode);
  const memoryPoints = extractMemoryPoints(cleaned);
  const suggestedNext = generateSuggestedNext(compressed, selectedMode);

  return {
    optimizedPrompt: optimized.trim(),
    contextSummary,
    memoryPoints,
    suggestedNext,
    metadata: {
      inputType,
      detectedMode: selectedMode,
      originalLength: rawInput.length,
      optimizedLength: optimized.length,
      compressionRatio: Math.round((1 - optimized.length / Math.max(rawInput.length, 1)) * 100),
      timestamp: new Date().toISOString()
    }
  };
}


/* ══════════════════════════════════════════════
   OUTPUT HELPERS
   ══════════════════════════════════════════════ */

/**
 * Build a concise context summary
 */
function buildContextSummary(promptData, mode) {
  const parts = [];
  
  if (promptData.objective) {
    parts.push(`**Goal:** ${promptData.objective.substring(0, 150)}`);
  }
  parts.push(`**Mode:** ${mode.charAt(0).toUpperCase() + mode.slice(1)}`);
  
  if (promptData.constraints) {
    const constraintCount = (promptData.constraints.match(/^- /gm) || []).length;
    parts.push(`**Constraints:** ${constraintCount} identified`);
  }

  return parts.join('\n');
}

/**
 * Extract key memory points (facts the user should remember)
 */
function extractMemoryPoints(input) {
  const points = [];
  const sentences = input.split(/[.!?\n]+/).filter(s => s.trim().length > 15);

  // Look for definitive statements (decisions, facts, preferences)
  const memoryPatterns = [
    /(?:i (?:decided|chose|want|prefer|need|always|never))\s+(.+)/i,
    /(?:we (?:agreed|decided|chose|went with))\s+(.+)/i,
    /(?:the (?:answer|solution|approach|plan|decision) is)\s+(.+)/i,
    /(?:important|remember|note|key point|critical):\s*(.+)/i
  ];

  for (const sentence of sentences) {
    for (const pattern of memoryPatterns) {
      if (pattern.test(sentence)) {
        points.push(sentence.trim());
        break;
      }
    }
  }

  // Keep max 5 memory points
  return points.slice(0, 5);
}

/**
 * Generate a suggested next prompt based on the current one
 */
function generateSuggestedNext(promptData, mode) {
  if (!promptData.objective) return '';

  const suggestions = {
    founder: `Follow up: "Based on the above, what are the top 3 risks and how should I mitigate them?"`,
    student: `Follow up: "Can you give me a practice problem to test my understanding of this?"`,
    creator: `Follow up: "Can you create 3 variations of this with different tones?"`,
    developer: `Follow up: "Can you add error handling, tests, and documentation to this?"`,
    research: `Follow up: "What are the counter-arguments or limitations of this analysis?"`
  };

  return suggestions[mode] || `Follow up: "Can you expand on the most important part of your response?"`;
}


export { optimizePrompt, classifyInput, removeNoise, extractStructure, INPUT_TYPES };
