/**
 * Cloasta — OpenRouter API Client
 * 
 * Handles communication with OpenRouter to enhance the rule-based 
 * optimized prompt using an external AI model.
 */

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const DEFAULT_MODEL = 'deepseek/deepseek-chat-v3-0324:free';

/**
 * Enhance the rule-based prompt using OpenRouter API.
 * 
 * @param {string} ruleBasedPrompt - The prompt optimized by the rule-based engine.
 * @param {string} apiKey - The OpenRouter API Key.
 * @param {string} model - (Optional) The model to use.
 * @returns {Promise<object>} - Resolves with { optimizedPrompt, summary, memoryPoints, suggestedFollowUp }
 */
async function enhancePrompt(ruleBasedPrompt, apiKey, model = DEFAULT_MODEL) {
  if (!apiKey) {
    throw new Error('Missing API key for OpenRouter');
  }

  const systemPrompt = `You are the Cloasta AI workflow optimizer. Your task is to take a prompt that has already undergone basic rule-based formatting and elevate it to be highly effective, precise, and professional.

You MUST return your response as a valid JSON object with the following structure:
{
  "optimizedPrompt": "The fully enhanced prompt text ready to be sent to an AI",
  "summary": "A brief 1-2 sentence summary of the prompt's goal",
  "memoryPoints": ["Key fact 1", "Key fact 2"],
  "suggestedFollowUp": "A suggested follow-up question the user could ask the AI after this prompt"
}

Do not include any markdown formatting around the JSON (e.g., no \`\`\`json). Just return the raw JSON object.`;

  const payload = {
    model: model,
    messages: [
      {
        role: "system",
        content: systemPrompt
      },
      {
        role: "user",
        content: ruleBasedPrompt
      }
    ],
    response_format: { type: "json_object" } // Tell supporting models to output JSON
  };

  try {
    const response = await fetch(OPENROUTER_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://cloasta.app',
        'X-Title': 'Cloasta'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API error: ${response.status} - ${errText}`);
    }

    const data = await response.json();
    
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error('Invalid response format from OpenRouter');
    }

    const content = data.choices[0].message.content;
    
    // Parse the JSON response
    try {
      // Sometimes models wrap in markdown despite instructions
      const cleanContent = content.replace(/^```json\n?/, '').replace(/\n?```$/, '').trim();
      const parsed = JSON.parse(cleanContent);
      
      // Validate expected fields
      if (!parsed.optimizedPrompt) {
        throw new Error('Missing optimizedPrompt in AI response');
      }
      
      return {
        optimizedPrompt: parsed.optimizedPrompt,
        summary: parsed.summary || 'AI enhanced prompt.',
        memoryPoints: Array.isArray(parsed.memoryPoints) ? parsed.memoryPoints : [],
        suggestedFollowUp: parsed.suggestedFollowUp || ''
      };
    } catch (parseError) {
      console.error('Failed to parse AI response as JSON:', content);
      throw new Error('AI returned malformed JSON');
    }

  } catch (error) {
    console.error('Error enhancing prompt with OpenRouter:', error);
    throw error; // Rethrow so the caller can fallback to rule-based
  }
}

export { enhancePrompt, DEFAULT_MODEL };
