/**
 * Cloasta — AI Passport (Persistent Identity Manager)
 * 
 * Manages persistent user identity/context that enriches every generated prompt.
 * Stores data in chrome.storage.local (with optional Firestore sync).
 */

const PASSPORT_STORAGE_KEY = 'cloasta_ai_passport';

/**
 * Default empty passport structure
 */
function createEmptyPassport() {
  return {
    // Identity
    name: '',
    role: '',

    // Communication
    preferredTone: '',
    communicationStyle: '',

    // Context
    currentProjects: [],
    techStack: [],
    industry: '',
    expertise: [],

    // Preferences
    outputFormat: '',
    detailLevel: '',

    // Long-term Memory
    importantFacts: [],
    ongoingGoals: [],

    // Meta
    lastUpdated: null,
    version: 1
  };
}

/**
 * Get the current AI Passport from storage
 * @returns {Promise<object>} - The passport object
 */
async function getPassport() {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([PASSPORT_STORAGE_KEY], (result) => {
        const passport = result[PASSPORT_STORAGE_KEY] || createEmptyPassport();
        resolve(passport);
      });
    } else {
      // Fallback for non-extension context (testing)
      try {
        const stored = localStorage.getItem(PASSPORT_STORAGE_KEY);
        resolve(stored ? JSON.parse(stored) : createEmptyPassport());
      } catch (e) {
        resolve(createEmptyPassport());
      }
    }
  });
}

/**
 * Save the AI Passport to storage
 * @param {object} passport - The passport data to save
 * @returns {Promise<void>}
 */
async function savePassport(passport) {
  passport.lastUpdated = new Date().toISOString();

  return new Promise((resolve, reject) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [PASSPORT_STORAGE_KEY]: passport }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } else {
      try {
        localStorage.setItem(PASSPORT_STORAGE_KEY, JSON.stringify(passport));
        resolve();
      } catch (e) {
        reject(e);
      }
    }
  });
}

/**
 * Update specific fields of the passport (merge)
 * @param {object} updates - Fields to update
 * @returns {Promise<object>} - Updated passport
 */
async function updatePassport(updates) {
  const current = await getPassport();
  const updated = { ...current, ...updates };
  await savePassport(updated);
  return updated;
}

/**
 * Clear the entire passport
 * @returns {Promise<void>}
 */
async function clearPassport() {
  const empty = createEmptyPassport();
  await savePassport(empty);
  return empty;
}

/**
 * Check if passport has meaningful data
 * @param {object} passport
 * @returns {boolean}
 */
function hasPassportData(passport) {
  if (!passport) return false;
  return !!(
    passport.name ||
    passport.role ||
    passport.preferredTone ||
    passport.industry ||
    (passport.currentProjects && passport.currentProjects.length > 0) ||
    (passport.techStack && passport.techStack.length > 0) ||
    (passport.expertise && passport.expertise.length > 0) ||
    (passport.importantFacts && passport.importantFacts.length > 0) ||
    (passport.ongoingGoals && passport.ongoingGoals.length > 0)
  );
}

/**
 * Export passport as JSON string
 * @returns {Promise<string>}
 */
async function exportPassport() {
  const passport = await getPassport();
  return JSON.stringify(passport, null, 2);
}

/**
 * Import passport from JSON string
 * @param {string} jsonStr - JSON string of passport data
 * @returns {Promise<object>} - The imported passport
 */
async function importPassport(jsonStr) {
  try {
    const imported = JSON.parse(jsonStr);
    // Validate structure — merge with empty to ensure all fields exist
    const merged = { ...createEmptyPassport(), ...imported };
    merged.lastUpdated = new Date().toISOString();
    await savePassport(merged);
    return merged;
  } catch (e) {
    throw new Error('Invalid passport JSON: ' + e.message);
  }
}

/**
 * Generate a human-readable preview of the passport context
 * that would be injected into prompts
 * @param {object} passport
 * @returns {string}
 */
function generatePassportPreview(passport) {
  if (!hasPassportData(passport)) {
    return 'No passport data configured. Fill in your profile to enrich generated prompts.';
  }

  const lines = [];

  if (passport.name) lines.push(`👤 **Name:** ${passport.name}`);
  if (passport.role) lines.push(`💼 **Role:** ${passport.role}`);
  if (passport.industry) lines.push(`🏢 **Industry:** ${passport.industry}`);
  if (passport.preferredTone) lines.push(`🎯 **Tone:** ${passport.preferredTone}`);
  if (passport.communicationStyle) lines.push(`💬 **Style:** ${passport.communicationStyle}`);
  if (passport.outputFormat) lines.push(`📄 **Output:** ${passport.outputFormat}`);
  if (passport.detailLevel) lines.push(`📊 **Detail:** ${passport.detailLevel}`);

  if (passport.techStack && passport.techStack.length > 0) {
    lines.push(`🛠️ **Tech Stack:** ${passport.techStack.join(', ')}`);
  }
  if (passport.expertise && passport.expertise.length > 0) {
    lines.push(`🧠 **Expertise:** ${passport.expertise.join(', ')}`);
  }
  if (passport.currentProjects && passport.currentProjects.length > 0) {
    lines.push(`📁 **Projects:** ${passport.currentProjects.join(', ')}`);
  }
  if (passport.ongoingGoals && passport.ongoingGoals.length > 0) {
    lines.push(`🎯 **Goals:**`);
    passport.ongoingGoals.forEach(g => lines.push(`   - ${g}`));
  }
  if (passport.importantFacts && passport.importantFacts.length > 0) {
    lines.push(`📌 **Key Facts:**`);
    passport.importantFacts.forEach(f => lines.push(`   - ${f}`));
  }

  if (passport.lastUpdated) {
    const date = new Date(passport.lastUpdated).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
    lines.push(`\n_Last updated: ${date}_`);
  }

  return lines.join('\n');
}

export {
  getPassport,
  savePassport,
  updatePassport,
  clearPassport,
  hasPassportData,
  exportPassport,
  importPassport,
  generatePassportPreview,
  createEmptyPassport,
  PASSPORT_STORAGE_KEY
};
