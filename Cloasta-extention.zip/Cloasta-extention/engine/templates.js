/**
 * Cloasta — Mode-Specific Prompt Templates
 * 
 * Each mode defines a structured template that shapes how the optimized
 * prompt is formatted, what context is injected, and what output style
 * is expected from the target AI.
 */

const MODES = {
  founder: {
    id: 'founder',
    label: 'Founder',
    icon: '🚀',
    description: 'Strategic thinking, business decisions, metric-driven',
    preamble: `You are advising a startup founder. Prioritize actionable, strategic insights. Frame responses around business impact, scalability, and measurable outcomes. Be direct and decisive.`,
    structureGuide: {
      sections: ['Objective', 'Business Context', 'Constraints', 'Key Metrics', 'Desired Output'],
      outputExpectations: 'Provide strategic recommendations with clear action items, timelines, and expected impact. Use bullet points for quick scanning.',
      tone: 'Professional, direct, data-driven'
    },
    keywords: ['strategy', 'growth', 'revenue', 'market', 'product', 'scale', 'metrics', 'KPI', 'fundraise', 'pivot']
  },

  student: {
    id: 'student',
    label: 'Student',
    icon: '📚',
    description: 'Learning-focused, step-by-step, explanatory',
    preamble: `You are a patient, knowledgeable tutor. Explain concepts step-by-step. Use analogies and examples to make complex topics accessible. Check understanding at each stage.`,
    structureGuide: {
      sections: ['Learning Goal', 'Current Understanding', 'Specific Questions', 'Preferred Explanation Style'],
      outputExpectations: 'Break down explanations into clear steps. Use examples, analogies, and visual descriptions. Include practice questions or exercises when relevant.',
      tone: 'Patient, encouraging, clear, educational'
    },
    keywords: ['learn', 'understand', 'explain', 'study', 'homework', 'concept', 'course', 'exam', 'tutorial', 'practice']
  },

  creator: {
    id: 'creator',
    label: 'Creator',
    icon: '🎨',
    description: 'Creative freedom, audience-aware, brand-conscious',
    preamble: `You are a creative collaborator and content strategist. Help craft compelling content that resonates with the target audience. Balance creativity with strategic intent.`,
    structureGuide: {
      sections: ['Creative Brief', 'Target Audience', 'Tone & Voice', 'Platform/Medium', 'References/Inspiration'],
      outputExpectations: 'Provide creative options with reasoning. Consider audience psychology, platform best practices, and brand consistency. Offer variations when possible.',
      tone: 'Creative, engaging, audience-aware'
    },
    keywords: ['content', 'audience', 'brand', 'creative', 'write', 'design', 'story', 'social', 'video', 'blog']
  },

  developer: {
    id: 'developer',
    label: 'Developer',
    icon: '💻',
    description: 'Technical precision, code-focused, stack-aware',
    preamble: `You are a senior software engineer and technical architect. Provide precise, production-ready solutions. Consider edge cases, performance, security, and maintainability.`,
    structureGuide: {
      sections: ['Technical Goal', 'Tech Stack', 'Current Implementation', 'Constraints', 'Expected Behavior'],
      outputExpectations: 'Provide clean, well-commented code. Explain architectural decisions. Note potential issues, edge cases, and performance considerations. Follow best practices for the specified stack.',
      tone: 'Technical, precise, practical'
    },
    keywords: ['code', 'debug', 'api', 'function', 'deploy', 'build', 'test', 'error', 'framework', 'database']
  },

  research: {
    id: 'research',
    label: 'Research',
    icon: '🔬',
    description: 'Academic rigor, evidence-based, methodology-focused',
    preamble: `You are a research assistant with expertise in academic methodology. Provide evidence-based analysis with proper attribution. Distinguish between established facts, emerging evidence, and speculation.`,
    structureGuide: {
      sections: ['Research Question', 'Background Context', 'Methodology Preference', 'Scope & Boundaries', 'Output Format'],
      outputExpectations: 'Present findings with clear evidence hierarchy. Cite sources when possible. Note limitations and gaps. Use structured academic formatting.',
      tone: 'Analytical, evidence-based, nuanced'
    },
    keywords: ['research', 'study', 'evidence', 'analysis', 'data', 'hypothesis', 'literature', 'methodology', 'findings', 'review']
  }
};

/**
 * Detect the most likely mode based on input content
 * @param {string} input - The raw user input
 * @returns {string} - Mode ID (e.g., 'founder', 'developer')
 */
function detectMode(input) {
  const lowerInput = input.toLowerCase();
  let bestMode = 'founder'; // default
  let bestScore = 0;

  for (const [modeId, mode] of Object.entries(MODES)) {
    let score = 0;
    for (const keyword of mode.keywords) {
      // Count occurrences of each keyword
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      const matches = lowerInput.match(regex);
      if (matches) {
        score += matches.length;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMode = modeId;
    }
  }

  return bestMode;
}

/**
 * Apply a mode template to structured prompt data
 * @param {string} modeId - The mode to apply
 * @param {object} promptData - Extracted prompt components
 * @returns {string} - Formatted prompt with mode context
 */
function applyModeTemplate(modeId, promptData) {
  const mode = MODES[modeId] || MODES.founder;

  let result = '';

  // Add mode preamble as system context
  result += `## System Context\n${mode.preamble}\n\n`;

  // Add structured sections based on mode
  const sections = mode.structureGuide.sections;

  if (promptData.objective) {
    result += `## ${sections[0] || 'Objective'}\n${promptData.objective}\n\n`;
  }

  if (promptData.context) {
    result += `## ${sections[1] || 'Context'}\n${promptData.context}\n\n`;
  }

  if (promptData.constraints) {
    result += `## ${sections[3] || 'Constraints'}\n${promptData.constraints}\n\n`;
  }

  if (promptData.details) {
    result += `## Additional Details\n${promptData.details}\n\n`;
  }

  // Add output expectations
  result += `## Expected Output\n${mode.structureGuide.outputExpectations}\n\n`;
  result += `**Tone:** ${mode.structureGuide.tone}\n`;

  return result;
}

/**
 * Get all available modes for the UI
 * @returns {Array} - Array of mode objects with id, label, icon, description
 */
function getAvailableModes() {
  return Object.values(MODES).map(m => ({
    id: m.id,
    label: m.label,
    icon: m.icon,
    description: m.description
  }));
}

/**
 * Get a specific mode's configuration
 * @param {string} modeId 
 * @returns {object}
 */
function getMode(modeId) {
  return MODES[modeId] || MODES.founder;
}

export { MODES, detectMode, applyModeTemplate, getAvailableModes, getMode };
