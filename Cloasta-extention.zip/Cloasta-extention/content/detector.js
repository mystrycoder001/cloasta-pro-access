/**
 * Cloasta — Content Script Detector
 * 
 * Injected into supported AI chat platforms to:
 * 1. Inject a floating Cloasta badge.
 * 2. Extract conversation text when requested or when badge is clicked.
 * 3. Communicate with the background script and side panel.
 */

(function () {
  'use strict';

  // 1. Configuration & Constants
  const SUPPORTED_PLATFORMS = [
    'chatgpt.com',
    'claude.ai',
    'gemini.google.com',
    'chat.deepseek.com'
  ];

  const BADGE_ID = 'cloasta-floating-badge';

  // 2. Initialization
  function init() {
    // Check if we are on a supported platform
    const hostname = window.location.hostname;
    const isSupported = SUPPORTED_PLATFORMS.some(domain => hostname.includes(domain));
    
    if (!isSupported) return;

    // Avoid duplicate injections
    if (document.getElementById(BADGE_ID)) return;

    injectBadge();
    setupMessageListeners();
  }

  // 3. UI Injection
  function injectBadge() {
    // Inject pulse animation keyframes
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
      @keyframes cloasta-pulse {
        0% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0.3); }
        70% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 10px rgba(124, 58, 237, 0); }
        100% { box-shadow: 0 4px 12px rgba(124, 58, 237, 0.4), 0 0 0 0 rgba(124, 58, 237, 0); }
      }
    `;
    document.head.appendChild(styleSheet);

    const badge = document.createElement('div');
    badge.id = BADGE_ID;
    
    // Inline styles — premium gradient badge
    Object.assign(badge.style, {
      position: 'fixed',
      bottom: '24px',
      right: '24px',
      width: '48px',
      height: '48px',
      background: 'linear-gradient(135deg, #7c3aed 0%, #06b6d4 100%)',
      color: '#ffffff',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 4px 12px rgba(124, 58, 237, 0.4)',
      cursor: 'pointer',
      zIndex: '2147483647',
      transition: 'transform 0.2s ease, box-shadow 0.2s ease',
      fontSize: '24px',
      userSelect: 'none',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      animation: 'cloasta-pulse 2s infinite'
    });

    badge.innerText = '✦'; // Cloasta icon
    badge.title = 'Open Cloasta';

    // Hover effects
    badge.addEventListener('mouseenter', () => {
      badge.style.transform = 'scale(1.1)';
      badge.style.boxShadow = '0 6px 20px rgba(124, 58, 237, 0.5), 0 0 30px rgba(6, 182, 212, 0.3)';
      badge.style.animation = 'none';
    });
    badge.addEventListener('mouseleave', () => {
      badge.style.transform = 'scale(1)';
      badge.style.boxShadow = '0 4px 12px rgba(124, 58, 237, 0.4)';
      badge.style.animation = 'cloasta-pulse 2s infinite';
    });

    // Click handler
    badge.addEventListener('click', handleBadgeClick);

    document.body.appendChild(badge);
  }

  // 4. Interaction Handlers
  function handleBadgeClick() {
    try {
      if (!chrome?.runtime?.id) {
        console.warn("Cloasta runtime invalidated.");
        return;
      }

      chrome.runtime.sendMessage(
        { type: "CLOASTA_OPEN_PANEL" },
        () => {
          if (chrome.runtime.lastError) {
            console.warn("Runtime message failed:", chrome.runtime.lastError.message);
            return;
          }

          const conversationText = extractConversation();

          setTimeout(() => {
            try {
              if (!chrome?.runtime?.id) return;

              chrome.runtime.sendMessage({
                type: "CLOASTA_CONVERSATION_DATA",
                action: "summarize",
                text: conversationText
              });

            } catch (err) {
              console.warn("Conversation send failed:", err);
            }
          }, 500);
        }
      );
    } catch (err) {
      console.warn("Badge click failed:", err);
    }
  }

  // 5. Message Listeners
  function setupMessageListeners() {
    try {
      if (!chrome?.runtime?.id) return;
      
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'EXTRACT_CONVERSATION') {
          const text = extractConversation();
          sendResponse({ status: 'ok', text: text });
        }
        return true; // Keep channel open for async response if needed
      });
    } catch (err) {
      console.warn("Setup message listeners failed:", err);
    }
  }

  // 6. Extraction Logic (Lightweight & Resilient)
  function extractConversation() {
    try {
      // Try to find the main content area to avoid navbars/sidebars
      const containers = [
        document.querySelector('main'), // Standard HTML5, used by many
        document.querySelector('[class*="react-scroll-to-bottom"]'), // ChatGPT specific fallback
        document.querySelector('.ds-chat-message'), // DeepSeek specific fallback
        document.querySelector('message-content') // Gemini specific fallback
      ];

      const mainContainer = containers.find(c => c !== null);

      if (mainContainer) {
        return cleanText(mainContainer.innerText);
      }

      // Absolute fallback: entire body but try to ignore obvious noise
      console.warn('Cloasta: No main chat container found, falling back to body text.');
      return cleanText(document.body.innerText);

    } catch (e) {
      console.error('Cloasta: Failed to extract conversation', e);
      return '';
    }
  }

  // 7. Utility
  function cleanText(text) {
    if (!text) return '';
    return text
      .replace(/\n{3,}/g, '\n\n') // Collapse excessive newlines
      .trim();
  }

  // Run initialization
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
